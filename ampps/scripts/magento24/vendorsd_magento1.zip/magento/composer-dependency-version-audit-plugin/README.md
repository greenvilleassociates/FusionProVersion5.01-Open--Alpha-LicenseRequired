# composer-dependency-version-audit-plugin
validating packages through a composer plugin

# Version 1.8.4 (10800)
- fixed display of quoted text for Simplicity theme (contributed by WalterMisar https://github.com/oxwall/simplicity/pull/7)

# Version 1.8.1 (10200)
- fixed link for creation of topics in Forum Topics index widget;
- added check during creation of new topic to see if a forum for this new topic exists;
# contactimporter
Contact Importer plugin for Oxwall. Import Facebook, Google contacts

# event
Events plugin for Oxwall. Create public and private events within your community, let people RSVP and discuss.

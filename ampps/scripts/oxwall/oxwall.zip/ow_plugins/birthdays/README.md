# birthdays
Birthdays plugin for Oxwall. The list of upcoming birthdays for site users + widgets for index, dashboard and profiles

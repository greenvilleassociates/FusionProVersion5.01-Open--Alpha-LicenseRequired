# blogs
Blogs plugin for Oxwall. User blogs with archives, tags, comments and rates

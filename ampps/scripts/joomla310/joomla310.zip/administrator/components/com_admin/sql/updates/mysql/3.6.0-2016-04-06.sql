ALTER TABLE `#__redirect_links` MODIFY `new_url` VARCHAR(2048);
